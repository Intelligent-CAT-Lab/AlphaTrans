
/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */


package org.apache.commons.fileupload;

import org.evosuite.runtime.annotation.EvoSuiteClassExclude;
import org.junit.BeforeClass;
import org.junit.Before;
import org.junit.After;
import org.junit.AfterClass;
import org.evosuite.runtime.sandbox.Sandbox;
import org.evosuite.runtime.sandbox.Sandbox.SandboxMode;

import static org.evosuite.shaded.org.mockito.Mockito.*;
@EvoSuiteClassExclude
public class FileUploadBase_ESTest_scaffolding {

  @org.junit.Rule
  public org.evosuite.runtime.vnet.NonFunctionalRequirementRule nfr = new org.evosuite.runtime.vnet.NonFunctionalRequirementRule();

  private static final java.util.Properties defaultProperties = (java.util.Properties) java.lang.System.getProperties().clone(); 

  private org.evosuite.runtime.thread.ThreadStopper threadStopper =  new org.evosuite.runtime.thread.ThreadStopper (org.evosuite.runtime.thread.KillSwitchHandler.getInstance(), 3000);


  @BeforeClass
  public static void initEvoSuiteFramework() { 
    org.evosuite.runtime.RuntimeSettings.className = "org.apache.commons.fileupload.FileUploadBase"; 
    org.evosuite.runtime.GuiSupport.initialize(); 
    org.evosuite.runtime.RuntimeSettings.maxNumberOfThreads = 100; 
    org.evosuite.runtime.RuntimeSettings.maxNumberOfIterationsPerLoop = 10000; 
    org.evosuite.runtime.RuntimeSettings.mockSystemIn = true; 
    org.evosuite.runtime.RuntimeSettings.sandboxMode = org.evosuite.runtime.sandbox.Sandbox.SandboxMode.RECOMMENDED; 
    org.evosuite.runtime.sandbox.Sandbox.initializeSecurityManagerForSUT(); 
    org.evosuite.runtime.classhandling.JDKClassResetter.init();
    setSystemProperties();
    initializeClasses();
    org.evosuite.runtime.Runtime.getInstance().resetRuntime(); 
    try { initMocksToAvoidTimeoutsInTheTests(); } catch(ClassNotFoundException e) {} 
  } 

  @AfterClass
  public static void clearEvoSuiteFramework(){ 
    Sandbox.resetDefaultSecurityManager(); 
    java.lang.System.setProperties((java.util.Properties) defaultProperties.clone()); 
  } 

  @Before
  public void initTestCase(){ 
    threadStopper.storeCurrentThreads();
    threadStopper.startRecordingTime();
    org.evosuite.runtime.jvm.ShutdownHookHandler.getInstance().initHandler(); 
    org.evosuite.runtime.sandbox.Sandbox.goingToExecuteSUTCode(); 
    setSystemProperties(); 
    org.evosuite.runtime.GuiSupport.setHeadless(); 
    org.evosuite.runtime.Runtime.getInstance().resetRuntime(); 
    org.evosuite.runtime.agent.InstrumentingAgent.activate(); 
  } 

  @After
  public void doneWithTestCase(){ 
    threadStopper.killAndJoinClientThreads();
    org.evosuite.runtime.jvm.ShutdownHookHandler.getInstance().safeExecuteAddedHooks(); 
    org.evosuite.runtime.classhandling.JDKClassResetter.reset(); 
    resetClasses(); 
    org.evosuite.runtime.sandbox.Sandbox.doneWithExecutingSUTCode(); 
    org.evosuite.runtime.agent.InstrumentingAgent.deactivate(); 
    org.evosuite.runtime.GuiSupport.restoreHeadlessMode(); 
  } 

  public static void setSystemProperties() {
 
    java.lang.System.setProperties((java.util.Properties) defaultProperties.clone()); 
    java.lang.System.setProperty("user.dir", "/home/ali/Documents/AlphaTrans/java_projects/cleaned_final_projects/commons-fileupload"); 
    java.lang.System.setProperty("java.io.tmpdir", "/tmp"); 
  }

  private static void initializeClasses() {
    org.evosuite.runtime.classhandling.ClassStateSupport.initializeClasses(FileUploadBase_ESTest_scaffolding.class.getClassLoader() ,
      "org.apache.commons.fileupload.FileUploadBase$InvalidContentTypeException",
      "org.apache.commons.fileupload.FileUploadBase$FileSizeLimitExceededException",
      "org.apache.commons.fileupload.FileItem",
      "org.apache.commons.fileupload.FileUploadBase$SizeException",
      "org.apache.commons.fileupload.FileUploadBase$SizeLimitExceededException",
      "org.apache.commons.fileupload.FileItemHeaders",
      "org.apache.commons.fileupload.FileItemFactory",
      "org.apache.commons.fileupload.util.FileItemHeadersImpl",
      "org.apache.commons.fileupload.ProgressListener",
      "org.apache.commons.fileupload.RequestContext",
      "org.apache.commons.fileupload.FileUpload",
      "org.apache.commons.fileupload.FileUploadBase$FileUploadIOException",
      "org.apache.commons.fileupload.FileItemHeadersSupport",
      "org.apache.commons.fileupload.FileUploadBase$IOFileUploadException",
      "org.apache.commons.fileupload.ParameterParser",
      "org.apache.commons.fileupload.FileUploadBase$UnknownSizeException",
      "org.apache.commons.fileupload.FileUploadException",
      "org.apache.commons.fileupload.FileUploadBase"
    );
  } 
  private static void initMocksToAvoidTimeoutsInTheTests() throws ClassNotFoundException { 
    mock(Class.forName("org.apache.commons.fileupload.FileItemFactory", false, FileUploadBase_ESTest_scaffolding.class.getClassLoader()));
    mock(Class.forName("org.apache.commons.fileupload.RequestContext", false, FileUploadBase_ESTest_scaffolding.class.getClassLoader()));
  }

  private static void resetClasses() {
    org.evosuite.runtime.classhandling.ClassResetter.getInstance().setClassLoader(FileUploadBase_ESTest_scaffolding.class.getClassLoader()); 

    org.evosuite.runtime.classhandling.ClassStateSupport.resetClasses(
      "org.apache.commons.fileupload.FileUploadBase",
      "org.apache.commons.fileupload.FileUploadException",
      "org.apache.commons.fileupload.FileUploadBase$SizeException",
      "org.apache.commons.fileupload.FileUploadBase$FileSizeLimitExceededException",
      "org.apache.commons.fileupload.FileUpload",
      "org.apache.commons.fileupload.util.FileItemHeadersImpl",
      "org.apache.commons.fileupload.FileUploadBase$SizeLimitExceededException",
      "org.apache.commons.fileupload.FileUploadBase$InvalidContentTypeException",
      "org.apache.commons.fileupload.FileUploadBase$FileUploadIOException",
      "org.apache.commons.fileupload.ParameterParser",
      "org.apache.commons.fileupload.FileUploadBase$IOFileUploadException",
      "org.apache.commons.fileupload.util.mime.MimeUtility"
    );
  }
}
