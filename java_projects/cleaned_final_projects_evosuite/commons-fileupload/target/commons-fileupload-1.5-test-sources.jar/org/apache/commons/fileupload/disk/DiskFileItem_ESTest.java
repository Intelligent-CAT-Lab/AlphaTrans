
/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */


package org.apache.commons.fileupload.disk;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.File;
import java.net.URI;
import org.apache.commons.fileupload.disk.DiskFileItem;
import org.apache.commons.fileupload.util.FileItemHeadersImpl;
import org.evosuite.runtime.EvoRunner;
import org.evosuite.runtime.EvoRunnerParameters;
import org.evosuite.runtime.mock.java.io.MockFile;
import org.evosuite.runtime.mock.java.net.MockURI;
import org.junit.runner.RunWith;

@RunWith(EvoRunner.class) @EvoRunnerParameters(mockJVMNonDeterminism = true, useVFS = true, useVNET = true, resetStaticState = true) 
public class DiskFileItem_ESTest extends DiskFileItem_ESTest_scaffolding {

  @Test(timeout = 4000)
  public void test00()  throws Throwable  {
      MockFile mockFile0 = new MockFile("");
      DiskFileItem diskFileItem0 = new DiskFileItem((String) null, "", true, "org.apache.commons.fileupload.disk.DiskFileItem", 0, mockFile0);
      boolean boolean0 = diskFileItem0.isFormField();
      assertEquals("", diskFileItem0.getContentType());
      assertTrue(boolean0);
      assertEquals("ISO-8859-1", diskFileItem0.getDefaultCharset());
  }

  @Test(timeout = 4000)
  public void test01()  throws Throwable  {
      MockFile mockFile0 = new MockFile("", "");
      DiskFileItem diskFileItem0 = new DiskFileItem("", "", true, "UTF8", 299, mockFile0);
      File file0 = diskFileItem0.getTempFile();
      File file1 = MockFile.createTempFile("UTF8", "", file0);
      //  // Unstable assertion: assertEquals("/upload_00000000_0100_4000_8200_000003000000_00000053.tmp", file1.getParent());
      
      File file2 = diskFileItem0.getTempFile();
      //  // Unstable assertion: assertEquals("/upload_00000000_0100_4000_8200_000003000000_00000053.tmp", file2.toString());
  }

  @Test(timeout = 4000)
  public void test02()  throws Throwable  {
      MockFile mockFile0 = new MockFile("org.apache.commons.fileupload.util.FileItemHeadersImpl", "=/r+>pCha:h]}7f");
      DiskFileItem diskFileItem0 = new DiskFileItem((String) null, "=/r+>pCha:h]}7f", true, (String) null, (-1458), mockFile0);
      String string0 = diskFileItem0.getName();
      assertTrue(diskFileItem0.isFormField());
      assertEquals("=/r+>pCha:h]}7f", diskFileItem0.getContentType());
      assertNull(string0);
      assertEquals("ISO-8859-1", diskFileItem0.getDefaultCharset());
  }

  @Test(timeout = 4000)
  public void test03()  throws Throwable  {
      File file0 = MockFile.createTempFile("cr(7Y_)3xc]", "org.apache.commons.fileupload.disk.DiskFileItem");
      DiskFileItem diskFileItem0 = new DiskFileItem("q>|\"I", "qW5", false, "cr(7Y_)3xc]", (-2033), file0);
      String string0 = diskFileItem0.getName();
      assertEquals("qW5", diskFileItem0.getContentType());
      assertFalse(diskFileItem0.isFormField());
      assertEquals("ISO-8859-1", diskFileItem0.getDefaultCharset());
      assertEquals("q>|\"I", diskFileItem0.getFieldName());
      assertEquals("cr(7Y_)3xc]", string0);
  }

  @Test(timeout = 4000)
  public void test04()  throws Throwable  {
      MockFile mockFile0 = new MockFile("&ST2Spw");
      DiskFileItem diskFileItem0 = new DiskFileItem("ISO-8859-1", "", false, "", 0, mockFile0);
      FileItemHeadersImpl fileItemHeadersImpl0 = new FileItemHeadersImpl();
      diskFileItem0.setHeaders(fileItemHeadersImpl0);
      diskFileItem0.getHeaders();
      assertEquals("", diskFileItem0.getContentType());
      assertEquals("ISO-8859-1", diskFileItem0.getFieldName());
      assertEquals("ISO-8859-1", diskFileItem0.getDefaultCharset());
      assertFalse(diskFileItem0.isFormField());
  }

  @Test(timeout = 4000)
  public void test05()  throws Throwable  {
      MockFile mockFile0 = new MockFile("");
      DiskFileItem diskFileItem0 = new DiskFileItem((String) null, "", true, "org.apache.commons.fileupload.disk.DiskFileItem", 0, mockFile0);
      String string0 = diskFileItem0.getFieldName();
      assertNull(string0);
      assertEquals("", diskFileItem0.getContentType());
      assertEquals("ISO-8859-1", diskFileItem0.getDefaultCharset());
      assertTrue(diskFileItem0.isFormField());
  }

  @Test(timeout = 4000)
  public void test06()  throws Throwable  {
      MockFile mockFile0 = new MockFile("upload_%s_%s.tmp");
      DiskFileItem diskFileItem0 = new DiskFileItem("", "upload_%s_%s.tmp", false, "", 2952, mockFile0);
      String string0 = diskFileItem0.getFieldName();
      assertEquals("ISO-8859-1", diskFileItem0.getDefaultCharset());
      assertEquals("", string0);
      assertEquals("upload_%s_%s.tmp", diskFileItem0.getContentType());
      assertFalse(diskFileItem0.isFormField());
  }

  @Test(timeout = 4000)
  public void test07()  throws Throwable  {
      MockFile mockFile0 = new MockFile("v$IJC)d$uJvO2$9aUX!", "v$IJC)d$uJvO2$9aUX!");
      DiskFileItem diskFileItem0 = new DiskFileItem("", "", true, "", 0, mockFile0);
      assertEquals("ISO-8859-1", diskFileItem0.getDefaultCharset());
      
      diskFileItem0.setDefaultCharset((String) null);
      String string0 = diskFileItem0.getDefaultCharset();
      assertEquals("", diskFileItem0.getFieldName());
      assertTrue(diskFileItem0.isFormField());
      assertEquals("", diskFileItem0.getContentType());
      assertNull(string0);
  }

  @Test(timeout = 4000)
  public void test08()  throws Throwable  {
      URI uRI0 = MockURI.aFileURI;
      MockFile mockFile0 = new MockFile(uRI0);
      DiskFileItem diskFileItem0 = new DiskFileItem("", "", false, "", 0, mockFile0);
      assertEquals("ISO-8859-1", diskFileItem0.getDefaultCharset());
      
      diskFileItem0.setDefaultCharset("");
      diskFileItem0.getDefaultCharset();
      assertEquals("", diskFileItem0.getDefaultCharset());
  }

  @Test(timeout = 4000)
  public void test09()  throws Throwable  {
      MockFile mockFile0 = new MockFile("u8d0!/R", "%zr8");
      DiskFileItem diskFileItem0 = new DiskFileItem((String) null, (String) null, false, "\"m", 3475, mockFile0);
      String string0 = diskFileItem0.getContentType();
      assertEquals("ISO-8859-1", diskFileItem0.getDefaultCharset());
      assertFalse(diskFileItem0.isFormField());
      assertNull(string0);
  }

  @Test(timeout = 4000)
  public void test10()  throws Throwable  {
      MockFile mockFile0 = new MockFile("");
      DiskFileItem diskFileItem0 = new DiskFileItem("ja_jp.eucjp", "", false, (String) null, 0, mockFile0);
      String string0 = diskFileItem0.getContentType();
      assertEquals("ISO-8859-1", diskFileItem0.getDefaultCharset());
      assertEquals("", string0);
      assertEquals("ja_jp.eucjp", diskFileItem0.getFieldName());
      assertNotNull(string0);
      assertFalse(diskFileItem0.isFormField());
  }

  @Test(timeout = 4000)
  public void test11()  throws Throwable  {
      MockFile mockFile0 = new MockFile("upload_%s_%s.tmp");
      DiskFileItem diskFileItem0 = new DiskFileItem("", "upload_%s_%s.tmp", false, "", 2952, mockFile0);
      String string0 = diskFileItem0.getContentType();
      assertFalse(diskFileItem0.isFormField());
      assertEquals("upload_%s_%s.tmp", string0);
      assertEquals("", diskFileItem0.getFieldName());
      assertEquals("ISO-8859-1", diskFileItem0.getDefaultCharset());
  }

  @Test(timeout = 4000)
  public void test12()  throws Throwable  {
      DiskFileItem diskFileItem0 = new DiskFileItem("cuM11<R>i KBP,1COv", "cuM11<R>i KBP,1COv", true, "cuM11<R>i KBP,1COv", 100000000, (File) null);
      File file0 = diskFileItem0.getTempFile();
      assertEquals("upload_00000000_0100_4000_8200_000003000000_00000000.tmp", file0.getName());
      assertNotNull(file0);
  }

  @Test(timeout = 4000)
  public void test13()  throws Throwable  {
      MockFile mockFile0 = new MockFile("");
      DiskFileItem diskFileItem0 = new DiskFileItem("ja_jp.eucjp", "", false, (String) null, 0, mockFile0);
      String string0 = diskFileItem0.getDefaultCharset();
      assertFalse(diskFileItem0.isFormField());
      assertEquals("", diskFileItem0.getContentType());
      assertEquals("ISO-8859-1", string0);
      assertEquals("ja_jp.eucjp", diskFileItem0.getFieldName());
  }

  @Test(timeout = 4000)
  public void test14()  throws Throwable  {
      MockFile mockFile0 = new MockFile("", "");
      DiskFileItem diskFileItem0 = new DiskFileItem("", "", true, "UTF8", 299, mockFile0);
      diskFileItem0.setFieldName("");
      assertTrue(diskFileItem0.isFormField());
      assertEquals("", diskFileItem0.getContentType());
      assertEquals("", diskFileItem0.getFieldName());
      assertEquals("ISO-8859-1", diskFileItem0.getDefaultCharset());
  }

  @Test(timeout = 4000)
  public void test15()  throws Throwable  {
      MockFile mockFile0 = new MockFile("+");
      DiskFileItem diskFileItem0 = new DiskFileItem("+", "+", true, "+", 1638, mockFile0);
      diskFileItem0.setFormField(true);
      assertEquals("+", diskFileItem0.getContentType());
      assertTrue(diskFileItem0.isFormField());
      assertEquals("ISO-8859-1", diskFileItem0.getDefaultCharset());
      assertEquals("+", diskFileItem0.getFieldName());
  }

  @Test(timeout = 4000)
  public void test16()  throws Throwable  {
      MockFile mockFile0 = new MockFile("");
      DiskFileItem diskFileItem0 = new DiskFileItem("ja_jp.eucjp", "", false, (String) null, 0, mockFile0);
      boolean boolean0 = diskFileItem0.isFormField();
      assertFalse(boolean0);
      assertEquals("", diskFileItem0.getContentType());
      assertEquals("ja_jp.eucjp", diskFileItem0.getFieldName());
      assertEquals("ISO-8859-1", diskFileItem0.getDefaultCharset());
  }

  @Test(timeout = 4000)
  public void test17()  throws Throwable  {
      MockFile mockFile0 = new MockFile("");
      DiskFileItem diskFileItem0 = new DiskFileItem("ja_jp.eucjp", "", false, (String) null, 0, mockFile0);
      diskFileItem0.getHeaders();
      assertFalse(diskFileItem0.isFormField());
      assertEquals("", diskFileItem0.getContentType());
      assertEquals("ja_jp.eucjp", diskFileItem0.getFieldName());
      assertEquals("ISO-8859-1", diskFileItem0.getDefaultCharset());
  }

  @Test(timeout = 4000)
  public void test18()  throws Throwable  {
      MockFile mockFile0 = new MockFile("+");
      DiskFileItem diskFileItem0 = new DiskFileItem("+", "+", true, "+", 1638, mockFile0);
      String string0 = diskFileItem0.getFieldName();
      assertEquals("+", string0);
      assertTrue(diskFileItem0.isFormField());
      assertEquals("+", diskFileItem0.getContentType());
      assertEquals("ISO-8859-1", diskFileItem0.getDefaultCharset());
  }

  @Test(timeout = 4000)
  public void test19()  throws Throwable  {
      URI uRI0 = MockURI.aFileURI;
      MockFile mockFile0 = new MockFile(uRI0);
      DiskFileItem diskFileItem0 = new DiskFileItem("", "", false, "", 0, mockFile0);
      String string0 = diskFileItem0.getName();
      assertEquals("", diskFileItem0.getContentType());
      assertEquals("", string0);
      assertEquals("ISO-8859-1", diskFileItem0.getDefaultCharset());
      assertEquals("", diskFileItem0.getFieldName());
      assertFalse(diskFileItem0.isFormField());
  }

  @Test(timeout = 4000)
  public void test20()  throws Throwable  {
      MockFile mockFile0 = new MockFile("", "");
      DiskFileItem diskFileItem0 = new DiskFileItem("", "", true, "UTF8", 299, mockFile0);
      diskFileItem0.getCharSet();
      assertTrue(diskFileItem0.isFormField());
      assertEquals("ISO-8859-1", diskFileItem0.getDefaultCharset());
      assertEquals("", diskFileItem0.getContentType());
      assertEquals("", diskFileItem0.getFieldName());
  }
}
