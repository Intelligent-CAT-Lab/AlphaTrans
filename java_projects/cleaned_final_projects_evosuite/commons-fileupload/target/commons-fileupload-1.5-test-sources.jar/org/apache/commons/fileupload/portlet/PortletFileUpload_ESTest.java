
/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */


package org.apache.commons.fileupload.portlet;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.evosuite.shaded.org.mockito.Mockito.*;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadBase;
import org.apache.commons.fileupload.portlet.PortletFileUpload;
import org.evosuite.runtime.EvoRunner;
import org.evosuite.runtime.EvoRunnerParameters;
import org.evosuite.runtime.ViolatedAssumptionAnswer;
import org.junit.runner.RunWith;

@RunWith(EvoRunner.class) @EvoRunnerParameters(mockJVMNonDeterminism = true, useVFS = true, useVNET = true, resetStaticState = true) 
public class PortletFileUpload_ESTest extends PortletFileUpload_ESTest_scaffolding {

  @Test(timeout = 4000)
  public void test0()  throws Throwable  {
      FileItemFactory fileItemFactory0 = mock(FileItemFactory.class, new ViolatedAssumptionAnswer());
      PortletFileUpload portletFileUpload0 = new PortletFileUpload(fileItemFactory0);
      assertEquals(1024, FileUploadBase.MAX_HEADER_SIZE);
  }

  @Test(timeout = 4000)
  public void test1()  throws Throwable  {
      PortletFileUpload portletFileUpload0 = PortletFileUpload.PortletFileUpload1();
      assertEquals((-1L), portletFileUpload0.getFileSizeMax());
  }
}
