
/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */


package org.apache.commons.fileupload;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.evosuite.runtime.EvoAssertions.*;
import java.util.Map;
import org.apache.commons.fileupload.ParameterParser;
import org.evosuite.runtime.EvoRunner;
import org.evosuite.runtime.EvoRunnerParameters;
import org.junit.runner.RunWith;

@RunWith(EvoRunner.class) @EvoRunnerParameters(mockJVMNonDeterminism = true, useVFS = true, useVNET = true, resetStaticState = true) 
public class ParameterParser_ESTest extends ParameterParser_ESTest_scaffolding {

  @Test(timeout = 4000)
  public void test00()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      char[] charArray0 = new char[4];
      charArray0[2] = '#';
      charArray0[3] = '3';
      Map<String, String> map0 = parameterParser0.parse0("%_NM#dicXH sb>;RR3", charArray0);
      assertEquals(2, map0.size());
  }

  @Test(timeout = 4000)
  public void test01()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      char[] charArray0 = new char[3];
      charArray0[0] = '=';
      Map<String, String> map0 = parameterParser0.parse2(charArray0, 'b');
      assertTrue(map0.isEmpty());
  }

  @Test(timeout = 4000)
  public void test02()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      char[] charArray0 = new char[6];
      Map<String, String> map0 = parameterParser0.parse3(charArray0, 0, (-1), '/');
      assertFalse(parameterParser0.isLowerCaseNames());
      assertTrue(map0.isEmpty());
  }

  @Test(timeout = 4000)
  public void test03()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      assertFalse(parameterParser0.isLowerCaseNames());
      
      parameterParser0.setLowerCaseNames(true);
      boolean boolean0 = parameterParser0.isLowerCaseNames();
      assertTrue(boolean0);
  }

  @Test(timeout = 4000)
  public void test04()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      char[] charArray0 = new char[8];
      charArray0[0] = '=';
      Map<String, String> map0 = parameterParser0.parse3(charArray0, 0, 2, 'j');
      assertTrue(map0.isEmpty());
  }

  @Test(timeout = 4000)
  public void test05()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      char[] charArray0 = new char[8];
      charArray0[1] = '=';
      Map<String, String> map0 = parameterParser0.parse3(charArray0, 0, 2, 'd');
      assertEquals(1, map0.size());
  }

  @Test(timeout = 4000)
  public void test06()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      char[] charArray0 = new char[8];
      Map<String, String> map0 = parameterParser0.parse3(charArray0, 0, 2, 'd');
      assertFalse(map0.isEmpty());
      assertFalse(parameterParser0.isLowerCaseNames());
  }

  @Test(timeout = 4000)
  public void test07()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      char[] charArray0 = new char[3];
      Map<String, String> map0 = parameterParser0.parse2(charArray0, 'b');
      assertEquals(1, map0.size());
      assertFalse(parameterParser0.isLowerCaseNames());
  }

  @Test(timeout = 4000)
  public void test08()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      parameterParser0.parse1((String) null, 'K');
      assertFalse(parameterParser0.isLowerCaseNames());
  }

  @Test(timeout = 4000)
  public void test09()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      Map<String, String> map0 = parameterParser0.parse1("=;Oj|YvQwe\"", 'V');
      assertEquals(0, map0.size());
  }

  @Test(timeout = 4000)
  public void test10()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      Map<String, String> map0 = parameterParser0.parse1("J_2IM4Yt=c`", 'w');
      assertFalse(parameterParser0.isLowerCaseNames());
      assertEquals(1, map0.size());
  }

  @Test(timeout = 4000)
  public void test11()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      char[] charArray0 = new char[6];
      charArray0[4] = '?';
      parameterParser0.setLowerCaseNames(true);
      // Undeclared exception!
      try { 
        parameterParser0.parse3(charArray0, 0, 107, '?');
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void test12()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      parameterParser0.parse3((char[]) null, 66, 66, '/');
      assertFalse(parameterParser0.isLowerCaseNames());
  }

  @Test(timeout = 4000)
  public void test13()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      parameterParser0.parse2((char[]) null, ')');
      assertFalse(parameterParser0.isLowerCaseNames());
  }

  @Test(timeout = 4000)
  public void test14()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      char[] charArray0 = new char[7];
      charArray0[0] = 'K';
      charArray0[1] = 'K';
      Map<String, String> map0 = parameterParser0.parse0("K=\"\"2O~9F", charArray0);
      assertFalse(parameterParser0.isLowerCaseNames());
      assertTrue(map0.isEmpty());
  }

  @Test(timeout = 4000)
  public void test15()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      char[] charArray0 = new char[2];
      parameterParser0.parse0((String) null, charArray0);
      assertFalse(parameterParser0.isLowerCaseNames());
  }

  @Test(timeout = 4000)
  public void test16()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      char[] charArray0 = new char[0];
      parameterParser0.parse0("", charArray0);
      assertFalse(parameterParser0.isLowerCaseNames());
  }

  @Test(timeout = 4000)
  public void test17()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      parameterParser0.parse0("FN>TZE6|X6KB!;xr&", (char[]) null);
      assertFalse(parameterParser0.isLowerCaseNames());
  }

  @Test(timeout = 4000)
  public void test18()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      char[] charArray0 = new char[2];
      charArray0[0] = '(';
      Map<String, String> map0 = parameterParser0.parse0("=8HTjM:*BF_P{F!!-(O", charArray0);
      assertFalse(parameterParser0.isLowerCaseNames());
      assertEquals(1, map0.size());
  }

  @Test(timeout = 4000)
  public void test19()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      char[] charArray0 = new char[1];
      Map<String, String> map0 = parameterParser0.parse0("Unknown RFC 2047 encoding: ", charArray0);
      assertEquals(1, map0.size());
  }

  @Test(timeout = 4000)
  public void test20()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      parameterParser0.parse1(" \t\r\n", '`');
      assertFalse(parameterParser0.isLowerCaseNames());
  }

  @Test(timeout = 4000)
  public void test21()  throws Throwable  {
      ParameterParser parameterParser0 = new ParameterParser();
      boolean boolean0 = parameterParser0.isLowerCaseNames();
      assertFalse(boolean0);
  }
}
