
/*
  Licensed to the Apache Software Foundation (ASF) under one or more
  contributor license agreements.  See the NOTICE file distributed with
  this work for additional information regarding copyright ownership.
  The ASF licenses this file to You under the Apache License, Version 2.0
  (the "License"); you may not use this file except in compliance with
  the License.  You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
 */


package org.apache.commons.validator.routines;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.evosuite.runtime.EvoAssertions.*;
import java.text.ChoiceFormat;
import java.text.DateFormat;
import java.text.Format;
import java.text.MessageFormat;
import java.text.NumberFormat;
import java.util.Calendar;
import java.util.Locale;
import org.apache.commons.validator.routines.BigDecimalValidator;
import org.apache.commons.validator.routines.ByteValidator;
import org.apache.commons.validator.routines.CalendarValidator;
import org.apache.commons.validator.routines.DoubleValidator;
import org.apache.commons.validator.routines.IntegerValidator;
import org.apache.commons.validator.routines.LongValidator;
import org.apache.commons.validator.routines.PercentValidator;
import org.apache.commons.validator.routines.ShortValidator;
import org.evosuite.runtime.EvoRunner;
import org.evosuite.runtime.EvoRunnerParameters;
import org.evosuite.runtime.mock.java.text.MockDateFormat;
import org.evosuite.runtime.mock.java.text.MockSimpleDateFormat;
import org.junit.runner.RunWith;

@RunWith(EvoRunner.class) @EvoRunnerParameters(mockJVMNonDeterminism = true, useVFS = true, useVNET = true, resetStaticState = true) 
public class AbstractFormatValidator_ESTest extends AbstractFormatValidator_ESTest_scaffolding {

  @Test(timeout = 4000)
  public void test00()  throws Throwable  {
      CalendarValidator calendarValidator0 = CalendarValidator.CalendarValidator1();
      Locale locale0 = Locale.JAPAN;
      Format format0 = calendarValidator0.getFormat1(locale0);
      calendarValidator0.parse("", format0);
      assertTrue(calendarValidator0.isStrict());
  }

  @Test(timeout = 4000)
  public void test01()  throws Throwable  {
      CalendarValidator calendarValidator0 = CalendarValidator.getInstance();
      MockSimpleDateFormat mockSimpleDateFormat0 = new MockSimpleDateFormat("0.01");
      Object object0 = calendarValidator0.parse("0.01", mockSimpleDateFormat0);
      assertEquals("org.evosuite.runtime.mock.java.util.MockGregorianCalendar[time=?,areFieldsSet=false,areAllFieldsSet=false,lenient=true,zone=sun.util.calendar.ZoneInfo[id=\"GMT\",offset=0,dstSavings=0,useDaylight=false,transitions=0,lastRule=null],firstDayOfWeek=1,minimalDaysInFirstWeek=1,ERA=?,YEAR=?,MONTH=?,WEEK_OF_YEAR=?,WEEK_OF_MONTH=?,DAY_OF_MONTH=?,DAY_OF_YEAR=?,DAY_OF_WEEK=?,DAY_OF_WEEK_IN_MONTH=?,AM_PM=?,HOUR=?,HOUR_OF_DAY=?,MINUTE=?,SECOND=?,MILLISECOND=?,ZONE_OFFSET=?,DST_OFFSET=?]", object0.toString());
  }

  @Test(timeout = 4000)
  public void test02()  throws Throwable  {
      CalendarValidator calendarValidator0 = CalendarValidator.CalendarValidator1();
      Locale locale0 = Locale.GERMANY;
      calendarValidator0.isValid3("0,.01", "0,.01", locale0);
      assertTrue(calendarValidator0.isStrict());
  }

  @Test(timeout = 4000)
  public void test03()  throws Throwable  {
      Locale locale0 = Locale.CHINA;
      DoubleValidator doubleValidator0 = new DoubleValidator(false, (-1329));
      doubleValidator0.isValid3("#s 4-|J3aDQ4vKcvq", (String) null, locale0);
      assertFalse(doubleValidator0.isStrict());
  }

  @Test(timeout = 4000)
  public void test04()  throws Throwable  {
      PercentValidator percentValidator0 = PercentValidator.PercentValidator1();
      Locale locale0 = Locale.CHINA;
      percentValidator0.isValid2("J?GpsD'fB/+vf#s7B|_", locale0);
      assertTrue(percentValidator0.isStrict());
  }

  @Test(timeout = 4000)
  public void test05()  throws Throwable  {
      PercentValidator percentValidator0 = PercentValidator.PercentValidator1();
      percentValidator0.isValid1((String) null, "");
      assertTrue(percentValidator0.isStrict());
  }

  @Test(timeout = 4000)
  public void test06()  throws Throwable  {
      ShortValidator shortValidator0 = new ShortValidator(false, (-498));
      boolean boolean0 = shortValidator0.isValid0("0.01");
      assertTrue(boolean0);
  }

  @Test(timeout = 4000)
  public void test07()  throws Throwable  {
      CalendarValidator calendarValidator0 = CalendarValidator.CalendarValidator1();
      calendarValidator0.isValid0("0.01");
      assertTrue(calendarValidator0.isStrict());
  }

  @Test(timeout = 4000)
  public void test08()  throws Throwable  {
      PercentValidator percentValidator0 = PercentValidator.PercentValidator1();
      boolean boolean0 = percentValidator0.isStrict();
      assertTrue(boolean0);
  }

  @Test(timeout = 4000)
  public void test09()  throws Throwable  {
      ByteValidator byteValidator0 = ByteValidator.ByteValidator1();
      Locale locale0 = Locale.FRANCE;
      MessageFormat messageFormat0 = new MessageFormat("C[", locale0);
      byteValidator0.format4((Object) null, messageFormat0);
      assertTrue(byteValidator0.isStrict());
  }

  @Test(timeout = 4000)
  public void test10()  throws Throwable  {
      CalendarValidator calendarValidator0 = CalendarValidator.CalendarValidator1();
      MessageFormat messageFormat0 = new MessageFormat("");
      calendarValidator0.format4((Object) null, messageFormat0);
      assertTrue(calendarValidator0.isStrict());
  }

  @Test(timeout = 4000)
  public void test11()  throws Throwable  {
      CalendarValidator calendarValidator0 = CalendarValidator.CalendarValidator1();
      Locale locale0 = Locale.JAPAN;
      calendarValidator0.format3((Object) null, "0.01", locale0);
      assertTrue(calendarValidator0.isStrict());
  }

  @Test(timeout = 4000)
  public void test12()  throws Throwable  {
      CalendarValidator calendarValidator0 = CalendarValidator.CalendarValidator1();
      Locale locale0 = Locale.FRANCE;
      calendarValidator0.format2((Object) null, locale0);
      assertTrue(calendarValidator0.isStrict());
  }

  @Test(timeout = 4000)
  public void test13()  throws Throwable  {
      CalendarValidator calendarValidator0 = CalendarValidator.getInstance();
      String string0 = calendarValidator0.format1((Object) null, "0.01");
      assertNull(string0);
  }

  @Test(timeout = 4000)
  public void test14()  throws Throwable  {
      CalendarValidator calendarValidator0 = new CalendarValidator(false, (-1));
      calendarValidator0.format0((Object) null);
      assertFalse(calendarValidator0.isStrict());
  }

  @Test(timeout = 4000)
  public void test15()  throws Throwable  {
      DoubleValidator doubleValidator0 = DoubleValidator.DoubleValidator1();
      Double double0 = new Double(0);
      doubleValidator0.format0(double0);
      assertTrue(doubleValidator0.isStrict());
  }

  @Test(timeout = 4000)
  public void test16()  throws Throwable  {
      PercentValidator percentValidator0 = PercentValidator.PercentValidator1();
      NumberFormat numberFormat0 = NumberFormat.getPercentInstance();
      // Undeclared exception!
      try { 
        percentValidator0.parse("0.01", numberFormat0);
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         //
         // Character array is missing \"e\" notation exponential mark.
         //
         verifyException("java.math.BigDecimal", e);
      }
  }

  @Test(timeout = 4000)
  public void test17()  throws Throwable  {
      PercentValidator percentValidator0 = PercentValidator.PercentValidator1();
      DateFormat dateFormat0 = DateFormat.getDateInstance();
      // Undeclared exception!
      try { 
        percentValidator0.parse((String) null, dateFormat0);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
      }
  }

  @Test(timeout = 4000)
  public void test18()  throws Throwable  {
      CalendarValidator calendarValidator0 = CalendarValidator.CalendarValidator1();
      Locale locale0 = Locale.PRC;
      NumberFormat numberFormat0 = NumberFormat.getInstance(locale0);
      // Undeclared exception!
      try { 
        calendarValidator0.parse("0,.01", numberFormat0);
        fail("Expecting exception: ClassCastException");
      
      } catch(ClassCastException e) {
         //
         // class java.text.DecimalFormat cannot be cast to class java.text.DateFormat (java.text.DecimalFormat and java.text.DateFormat are in module java.base of loader 'bootstrap')
         //
         verifyException("org.apache.commons.validator.routines.CalendarValidator", e);
      }
  }

  @Test(timeout = 4000)
  public void test19()  throws Throwable  {
      PercentValidator percentValidator0 = PercentValidator.PercentValidator1();
      Locale locale0 = Locale.KOREA;
      // Undeclared exception!
      try { 
        percentValidator0.isValid3("0.01", (String) null, locale0);
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         //
         // Character array is missing \"e\" notation exponential mark.
         //
         verifyException("java.math.BigDecimal", e);
      }
  }

  @Test(timeout = 4000)
  public void test20()  throws Throwable  {
      PercentValidator percentValidator0 = PercentValidator.PercentValidator1();
      Locale locale0 = Locale.FRENCH;
      // Undeclared exception!
      try { 
        percentValidator0.isValid3("-L>4fzr',Jg]@qyT", "-L>4fzr',Jg]@qyT", locale0);
        fail("Expecting exception: IllegalArgumentException");
      
      } catch(IllegalArgumentException e) {
         //
         // Malformed pattern \"-L>4fzr',Jg]@qyT\"
         //
         verifyException("java.text.DecimalFormat", e);
      }
  }

  @Test(timeout = 4000)
  public void test21()  throws Throwable  {
      PercentValidator percentValidator0 = new PercentValidator(false);
      Locale locale0 = new Locale("0.01");
      // Undeclared exception!
      try { 
        percentValidator0.isValid2("0.01", locale0);
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         //
         // Character array is missing \"e\" notation exponential mark.
         //
         verifyException("java.math.BigDecimal", e);
      }
  }

  @Test(timeout = 4000)
  public void test22()  throws Throwable  {
      Locale locale0 = Locale.CANADA;
      CalendarValidator calendarValidator0 = new CalendarValidator(false, 4880);
      // Undeclared exception!
      try { 
        calendarValidator0.isValid2("0.01", locale0);
        fail("Expecting exception: IllegalArgumentException");
      
      } catch(IllegalArgumentException e) {
         //
         // Illegal date style 4880
         //
         verifyException("java.text.DateFormat", e);
      }
  }

  @Test(timeout = 4000)
  public void test23()  throws Throwable  {
      DoubleValidator doubleValidator0 = DoubleValidator.getInstance();
      // Undeclared exception!
      try { 
        doubleValidator0.isValid1("org.apache.commons.validator.routines.FloatValidator", "org.apache.commons.validator.routines.FloatValidator");
        fail("Expecting exception: IllegalArgumentException");
      
      } catch(IllegalArgumentException e) {
         //
         // Multiple decimal separators in pattern \"org.apache.commons.validator.routines.FloatValidator\"
         //
         verifyException("java.text.DecimalFormat", e);
      }
  }

  @Test(timeout = 4000)
  public void test24()  throws Throwable  {
      CalendarValidator calendarValidator0 = new CalendarValidator(false, 1868);
      // Undeclared exception!
      try { 
        calendarValidator0.isValid0("0u|3+PO|MUPg N4");
        fail("Expecting exception: IllegalArgumentException");
      
      } catch(IllegalArgumentException e) {
         //
         // Illegal date style 1868
         //
         verifyException("java.text.DateFormat", e);
      }
  }

  @Test(timeout = 4000)
  public void test25()  throws Throwable  {
      PercentValidator percentValidator0 = PercentValidator.PercentValidator1();
      Locale locale0 = Locale.KOREAN;
      // Undeclared exception!
      try { 
        percentValidator0.format4(locale0, (Format) null);
        fail("Expecting exception: NullPointerException");
      
      } catch(NullPointerException e) {
         //
         // no message in exception (getMessage() returned null)
         //
         verifyException("org.apache.commons.validator.routines.AbstractFormatValidator", e);
      }
  }

  @Test(timeout = 4000)
  public void test26()  throws Throwable  {
      PercentValidator percentValidator0 = PercentValidator.PercentValidator1();
      DateFormat dateFormat0 = MockDateFormat.getDateInstance(1);
      // Undeclared exception!
      try { 
        percentValidator0.format4((Object) null, dateFormat0);
        fail("Expecting exception: IllegalArgumentException");
      
      } catch(IllegalArgumentException e) {
         //
         // Cannot format given Object as a Date
         //
         verifyException("java.text.DateFormat", e);
      }
  }

  @Test(timeout = 4000)
  public void test27()  throws Throwable  {
      CalendarValidator calendarValidator0 = CalendarValidator.CalendarValidator1();
      MessageFormat messageFormat0 = new MessageFormat("0.01");
      // Undeclared exception!
      try { 
        calendarValidator0.format4("0.01", messageFormat0);
        fail("Expecting exception: ClassCastException");
      
      } catch(ClassCastException e) {
         //
         // class java.lang.String cannot be cast to class [Ljava.lang.Object; (java.lang.String and [Ljava.lang.Object; are in module java.base of loader 'bootstrap')
         //
         verifyException("java.text.MessageFormat", e);
      }
  }

  @Test(timeout = 4000)
  public void test28()  throws Throwable  {
      IntegerValidator integerValidator0 = IntegerValidator.IntegerValidator1();
      Double double0 = new Double(2350.169);
      ChoiceFormat choiceFormat0 = new ChoiceFormat("=ZU]3XHwkq.");
      // Undeclared exception!
      try { 
        integerValidator0.format4(double0, choiceFormat0);
        fail("Expecting exception: ArrayIndexOutOfBoundsException");
      
      } catch(ArrayIndexOutOfBoundsException e) {
         //
         // Index 0 out of bounds for length 0
         //
         verifyException("java.text.ChoiceFormat", e);
      }
  }

  @Test(timeout = 4000)
  public void test29()  throws Throwable  {
      PercentValidator percentValidator0 = PercentValidator.PercentValidator1();
      Locale locale0 = Locale.JAPANESE;
      // Undeclared exception!
      try { 
        percentValidator0.format3(locale0, "org.apache.commons.validator.routines.ByteValidator", locale0);
        fail("Expecting exception: IllegalArgumentException");
      
      } catch(IllegalArgumentException e) {
         //
         // Multiple decimal separators in pattern \"org.apache.commons.validator.routines.ByteValidator\"
         //
         verifyException("java.text.DecimalFormat", e);
      }
  }

  @Test(timeout = 4000)
  public void test30()  throws Throwable  {
      BigDecimalValidator bigDecimalValidator0 = BigDecimalValidator.BigDecimalValidator2();
      Locale locale0 = Locale.CHINA;
      // Undeclared exception!
      try { 
        bigDecimalValidator0.format2(locale0, locale0);
        fail("Expecting exception: IllegalArgumentException");
      
      } catch(IllegalArgumentException e) {
         //
         // Cannot format given Object as a Number
         //
         verifyException("java.text.DecimalFormat", e);
      }
  }

  @Test(timeout = 4000)
  public void test31()  throws Throwable  {
      PercentValidator percentValidator0 = PercentValidator.PercentValidator1();
      // Undeclared exception!
      try { 
        percentValidator0.format1(".,|h6zw,c=HFi", ".,|h6zw,c=HFi");
        fail("Expecting exception: IllegalArgumentException");
      
      } catch(IllegalArgumentException e) {
         //
         // Malformed pattern \".,|h6zw,c=HFi\"
         //
         verifyException("java.text.DecimalFormat", e);
      }
  }

  @Test(timeout = 4000)
  public void test32()  throws Throwable  {
      BigDecimalValidator bigDecimalValidator0 = BigDecimalValidator.BigDecimalValidator1(false);
      boolean boolean0 = bigDecimalValidator0.isStrict();
      assertFalse(boolean0);
  }

  @Test(timeout = 4000)
  public void test33()  throws Throwable  {
      DoubleValidator doubleValidator0 = DoubleValidator.DoubleValidator1();
      Double double0 = doubleValidator0.validate0("4bpT=C'ajc}};");
      assertNull(double0);
      assertTrue(doubleValidator0.isStrict());
  }

  @Test(timeout = 4000)
  public void test34()  throws Throwable  {
      LongValidator longValidator0 = new LongValidator(false, 0);
      longValidator0.isValid1("0u|3+PO|MUPg N4", "0u|3+PO|MUPg N4");
      assertFalse(longValidator0.isStrict());
  }

  @Test(timeout = 4000)
  public void test35()  throws Throwable  {
      PercentValidator percentValidator0 = PercentValidator.PercentValidator1();
      // Undeclared exception!
      try { 
        percentValidator0.format0(percentValidator0);
        fail("Expecting exception: IllegalArgumentException");
      
      } catch(IllegalArgumentException e) {
         //
         // Cannot format given Object as a Number
         //
         verifyException("java.text.DecimalFormat", e);
      }
  }

  @Test(timeout = 4000)
  public void test36()  throws Throwable  {
      DoubleValidator doubleValidator0 = DoubleValidator.getInstance();
      Double double0 = doubleValidator0.validate1("0u|3+PO|MUPg N4", "0u|3+PO|MUPg N4");
      String string0 = doubleValidator0.format1(double0, "0u|3+PO|MUPg N4");
      assertEquals("0u|3+PO|MUPg N4", string0);
  }

  @Test(timeout = 4000)
  public void test37()  throws Throwable  {
      DoubleValidator doubleValidator0 = DoubleValidator.getInstance();
      Double double0 = doubleValidator0.validate1("0u|3+PO|MUPg N4", "0u|3+PO|MUPg N4");
      Locale locale0 = Locale.ITALIAN;
      String string0 = doubleValidator0.format3(double0, "X?x64iTN-%bb9aYk`$", locale0);
      assertEquals("X?x64iTN-%bb9aYk`$0", string0);
  }

  @Test(timeout = 4000)
  public void test38()  throws Throwable  {
      ByteValidator byteValidator0 = ByteValidator.getInstance();
      Locale locale0 = Locale.GERMANY;
      boolean boolean0 = byteValidator0.isValid2("0.01", locale0);
      assertTrue(boolean0);
  }

  @Test(timeout = 4000)
  public void test39()  throws Throwable  {
      CalendarValidator calendarValidator0 = CalendarValidator.CalendarValidator1();
      Calendar calendar0 = calendarValidator0.validate2("0.01", "0.01");
      Locale locale0 = Locale.KOREAN;
      String string0 = calendarValidator0.format2(calendar0, locale0);
      assertTrue(calendarValidator0.isStrict());
      assertNotNull(string0);
  }

  @Test(timeout = 4000)
  public void test40()  throws Throwable  {
      PercentValidator percentValidator0 = PercentValidator.PercentValidator1();
      // Undeclared exception!
      try { 
        percentValidator0.isValid0("0.01");
        fail("Expecting exception: NumberFormatException");
      
      } catch(NumberFormatException e) {
         //
         // Character array is missing \"e\" notation exponential mark.
         //
         verifyException("java.math.BigDecimal", e);
      }
  }
}
